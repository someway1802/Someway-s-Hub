# Someway's Hub - Pro Aspect Ratio MP4 Media Player

**Someway's Hub** is a native offline Windows desktop media player featuring **Stremio-style video screen stretching**, custom X/Y axis scaling, multiple video file uploads, and Discord-style playlist reordering.

---

## 🌟 Key Features

- 🖥️ **Stremio-Style Screen Stretch**: Stretch video to fill 100% of your screen with zero letterboxing/pillarboxing.
- 📐 **Custom Aspect Ratio Control**: Stretch horizontal (X) and vertical (Y) axes independently using 3-digit inputs, sliders (+/- 5%), or hotkeys (`A`).
- 🎬 **Multi-File Upload & Playlist**: Upload multiple MP4/video files at once. Toggle the playlist via the **`📋` Clipboard button**.
- ↕️ **Discord-Style Video Reordering**: Click & drag video items up and down in the playlist pop-up panel or use quick `▲` / `▼` arrow controls.
- 🎨 **Orange & Green Liquid Glass Aesthetics**: Dark mode interface tailored with Green (`#22C55E`) and Orange (`#FF8C00`) accents.
- 🔇 **Quick Audio Mute Toggle**: Click the volume speaker icon or press `M` to mute/unmute audio.

---

## 🎮 Keyboard Shortcuts

| Hotkey | Action |
|---|---|
| `Space` / `K` | Play / Pause |
| `←` / `→` | Seek Backward / Forward 5s |
| `<` / `>` | Seek Backward / Forward 10s |
| `>>` / `]` | Fast Forward 1:35 (Skip Intro) |
| `↑` / `↓` | Volume Up / Down |
| `M` | Mute / Unmute Audio |
| `A` | Cycle Aspect Ratio Mode |
| `F` | Toggle Fullscreen |
| `Esc` | Exit Fullscreen |

---

## 📦 How to Run

1. Extract `Someway_Hub_Portable_v1.0.zip`.
2. Run `Someway's Hub.exe`.
3. Drop local MP4 files onto the screen or click `📋` -> `+ Add` to start playing!

---

*Created for high performance offline playback on Windows 10/11.*
